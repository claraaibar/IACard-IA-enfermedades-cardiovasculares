#Práctica 2 Minería de datos: Clara Aibar
####################################################
#ALGORITMO SUPERVISADO: MÁQUINA DE SOPORTE VECTORIAL
####################################################

setwd("C:/Users/Usuario/Documents/directorio R")

#install.packages("kernlab")
library(kernlab)


#Función para generar modelo y matriz de confusión
matriz_confusion_kernels <- function(kernel){
  
  clasificador <- ksvm(Heart.Disease ~ ., data = pat_car_train,
                               kernel = kernel)
  
  prediccion <- predict(clasificador, pat_car_test)
  
  matriz_confusion_svm <-confusionMatrix(pat_car_test$Heart.Disease, prediccion, positive = "Presence")
  
  precision_svm <- accuracy(actual = pat_car_test$Heart.Disease,
                                predicted = prediccion)
   
   precision_y_matriz_svm <- c(matriz_confusion_svm,precision_svm)
   
   return(precision_y_matriz_svm)

}

#HACER CON CADA KERNEL

matriz_van <- matriz_confusion_kernels("vanilladot");matriz_van


matriz_rbf <- matriz_confusion_kernels("rbfdot");matriz_rbf


matriz_pol <- matriz_confusion_kernels("polydot");matriz_pol


matriz_tan <- matriz_confusion_kernels("tanhdot");matriz_tan


matriz_lap <- matriz_confusion_kernels("laplacedot");matriz_lap


matriz_bes <- matriz_confusion_kernels("besseldot");matriz_bes


matriz_anv <- matriz_confusion_kernels("anovadot");matriz_anv


matriz_spl <- matriz_confusion_kernels("splinedot");matriz_spl

#La que más precisión muestra es la de "laplacedot"
matriz_lap
