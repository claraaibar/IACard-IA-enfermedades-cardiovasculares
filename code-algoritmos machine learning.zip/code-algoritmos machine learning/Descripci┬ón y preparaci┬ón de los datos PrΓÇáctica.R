#Práctica 2 Minería de datos: Clara Aibar

#DESCRIPICIÓN DE LA BASE DE DATOS Y SUS VARIABLES
##LAS VARIABLES GENERADAS EN ESTE SCRIPT SON NECESARIAS PARA APLICAR LOS ALGORITMOS

setwd("C:/Users/Usuario/Documents/directorio R")
pat_car <- read.csv("Heart_Disease_Prediction.csv.csv", stringsAsFactors = FALSE)

str(pat_car)
#install.packages("psych")
library(psych)


#########################################
##PREPARACIÓN DE LOS DATOS Y DESCRIPCIÓN DE LA BASE DE DATOS
##tipificación, normalización, aleatoriedad en su distribución y división en train y set 
#########################################

describe(pat_car)

#Crear función para tipificar
tipificar <-function(y){
  
  return(y-mean(y)/sd(y))
  
}

#Crear función para normalizar
normalizar <-function(x){
  
  return((x-min(x))/(max(x)-min(x)))
  
}

#Aplicar función para tipificar
#La variable a predecir al ser de tipo character no se puede ni tipificar ni normalizar: no se incluye
pat_car_tip <- as.data.frame(lapply(pat_car[-14], tipificar))

#Aplicar función para normalizar
pat_car_norm <- as.data.frame(lapply(pat_car_tip, normalizar))

#Se añade a la base de datos ya preparada la columna de la variable a predecir
pat_car_norm <- cbind(pat_car_norm,pat_car[14])

#La variable de patología que se quiere predecir se transforma en factor
pat_car_norm$Heart.Disease <- factor(pat_car_norm$Heart.Disease)

pat_car <- pat_car_norm

#Estructura de la base de datos preparada
str(pat_car_norm)

#Comprobamos que las variables están normalizadas y su valor máximo es de 1
hist(pat_car_norm$Age,col = "red")

summary(pat_car_norm$Age)

#Explorar correlación entre variables
pairs.panels(pat_car_norm)

#Comenzamos plantando semilla para obtener siempre la misma distribución de datos
#Con esta semilla se han logrado los mejores datos de precisión
set.seed(1222) 

#Reordenar de forma aleatoria de la base de datos para asegurarnos de que los datos están uniformemente distribuidos
#Podemos coger por filas los datos para sacarlos (que sea aleatorio, eliminar posobiles sesgos)
pat_car_rand <- pat_car[order(runif(270)),]

#Comprobamos los mismos valores para asegurar mismos resultados del modelo.
summary(pat_car$Cholesterol)
summary(pat_car_rand$Cholesterol)

#Se divide la base de datos en un 80% train 20% test 
# pat_car_train <- pat_car_rand[1:220,] ORIGINAL
# pat_car_test <- pat_car_rand[221:270,] ORIGINAL

pat_car_train <- pat_car_rand[1:189,]
pat_car_test <- pat_car_rand[190:270,]

#Comrobamos que las distribuciones de la variable a predecir son similares 
#en los datos de train y test respecto a los datos originales
prop.table(table(pat_car$Heart.Disease))
prop.table(table(pat_car_train$Heart.Disease))
prop.table(table(pat_car_test$Heart.Disease))
