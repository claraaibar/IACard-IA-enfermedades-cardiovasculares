#Práctica 2 Minería de datos: Clara Aibar
#########################################
#ALGORITMO SUPERVISADO: ÁRBOL DE DECISIÓN
#########################################

setwd("C:/Users/Usuario/Documents/directorio R")

#Librerías para el entrenamiento de modelos

#install.packages("C50")
library(C50)

#install.packages("mlbench")
library(mlbench)

#install.packages("rpart.plot")
library(rpart.plot)

#install.packages("rpart")
library(rpart)

#install.packages("Metrics")
library(Metrics)

#install.packages("caret")
library(caret)


#############################
## ENTRENAMIENTO DE MODELOS CON LA LIBRERÍA RPART
## BÚSQUEDA DEL MODELO CON MEJOR PRECISIÓN CON EL USO EN UN GRID DE HIPERPARÁMETROS 
## SE GENERAN 400 MODELOS DISTINTOS CON DIFERENTES PARÁMETROS Y SE ESCOGE EL MÁS PRECISO
#############################

# Indicamos el número mínimo de observaciones que deben existir en un nodo para que se haga un split 
# También se indica la profundidad máxima de cada nodo del árbol
# Estos son los parámetros que determinan las caracteríssticas de cada árbol
minsplit <- seq(1, 20, 1)
maxdepth <- seq(1, 20, 1)

# Generamos un grid con esas variables en el que se van a guardar los modelos 
# 20 filas y 20 columnas: 400 "huecos"
hyperparam_grid <- expand.grid(minsplit = minsplit, maxdepth = maxdepth)

# El número de modelos que se van a poder almacenar corresponde con las filas del grid
num_modelos <- nrow(hyperparam_grid)

# Creamos una variable vacía de tipo lista para guardar los modelos
pat_car_modelos <- list()

#Ahora se genera un bucle que vaya desde 0 hasta el número máximo de modelos almacenables en el grid (=400)
#En él se usa la función rpart para entrenar los modelos
#Es igual que crear un único modelo, pero con un bucle con un minsplit y maxdepth especificados:

#pat_car_model <- rpart(formula =Heart.Disease~.,
#                       data =pat_car_train,
#                       method ="class")

#Bucle que entrena 400 modelos
for (i in 1:num_modelos) {
  
  minsplit <- hyperparam_grid$minsplit[i]
  maxdepth <- hyperparam_grid$maxdepth[i]
  
  # Entrenamos un modelo con distintos parámetros en cada iteración y lo guardamos en la variable
  pat_car_modelos[[i]] <- rpart(formula = Heart.Disease ~ ., 
                                data = pat_car_train, 
                                method = "class",
                                minsplit = minsplit,
                                maxdepth = maxdepth)
}

# Observamos y ploteamos, por ejemplo, el modelo 90 de la lista de 400 (por curiosidad)
pat_car_modelos[[90]]

rpart.plot(x = pat_car_modelos[[90]], yesno = 2, type = 0, extra = 0)

# Le asigno a la variable de número de modelos la cantidad de modelos creados
#(No uso el valor de antes por si acaso se llegan a generar menos o hay algún problema)
num_modelos <- length(pat_car_modelos)

# Creo un vector vacío para almacenar los valores de precisión de los modelos generados
valores_precision <- c()

# Bucle que recorre el vector de los 400 modelos 
for (i in 1:num_modelos) {
  
  # Valor para conocer el modelo que se analiza en la iteración
  modelo <- pat_car_modelos[[i]]
  
  # Hago la predicción del modelo en los datos de testeo
  pred <- predict(object = modelo,
                  newdata = pat_car_test,
                  type = "class")
  
  # Calculo la precisión de los datos generados por el modelo con los reales del test
  #Almaceno su valor en la variable de precisiones
  valores_precision[i] <- accuracy(actual = pat_car_test$Heart.Disease, 
                                   predicted = pred)
}

# Identifico el modelo con la mayor precisión 
mayor_precision <- pat_car_modelos[[which.max(valores_precision)]]

#Miro los parámetros del mejor modelo (se han almacenado en la variable mayor_precision)
mayor_precision$control

# $minsplit
# [1] 1
# 
# $minbucket
# [1] 0
# 
# $cp
# [1] 0.01
# 
# $maxcompete
# [1] 4
# 
# $maxsurrogate
# [1] 5
# 
# $usesurrogate
# [1] 2
# 
# $surrogatestyle
# [1] 0
# 
# $maxdepth
# [1] 3
# 
# $xval
# [1] 10

#############################
## CÁLCULO DEL RENDIMIENTO DEL MODELO CON MAYOR PRECISIÓN
#############################

# Calculo la predicción del modelo sobre los datos de test
pred <- predict(object = mayor_precision,
                newdata = pat_car_test,
                type = "class")

# Calculo la precisión de los datos generados por el modelo con los reales del test
accuracy(actual = pat_car_test$Heart.Disease, 
         predicted = pred)

CrossTable(pat_car_test$Heart.Disease, pred,
                       prop.chisq = FALSE, prop.c = FALSE, prop.r = FALSE,
                       dnn = c('actual default', 'predicted default'))

confusionMatrix(pred, pat_car_test$Heart.Disease, positive = "Presence")

#############################
## PLOTEAR MODELO FINAL CON PRECISIÓN DEL 86%
#############################

#Ploteo árbol de decisión con mayor precisión: 86%
rpart.plot(x = mayor_precision, yesno = 2, type = 0, extra = 0)


#############################
## ENTRENAMIENTO DE MODELOS CON EL ALGORTIMO C5.0 (otra forma de entrenamiento)
#############################

#Creo bucle que genere 60 modelos con distintos boosts (del 1 al 60)

for(i in seq(from=1, to=60)){
  
  if(i==1){
    
    RES <- NULL
    
  }
  
  #Entrenamiento de los modelos con los datos de entrenamiento y distintos boosts
  modelo_boost <- C5.0(pat_car_train[-14], pat_car_train$Heart.Disease,
                       trials = i)
  
  #Predicción del modelo creado en la iteración con los datos de testeo
  prediccion <- predict(modelo_boost, pat_car_test)
  
  #Almaceno valor de precisión del modelo creado en la iteración
  valores_precision <- accuracy(actual = pat_car_test$Heart.Disease,
                                predicted = prediccion)
  
  #En la variable RES se almacena tanto el valor de precisión de cada modelo como el número de la iteración
  #Este último valor corresponde con el boost del modelo
  RES <- c(RES, valores_precision, i)
}

#Genero un dataframe con los datos de precisión y boosts ( byrow = T, cada uno en una columna)
RES <- data.frame(matrix(RES, ncol = 2, byrow = T))

colnames(RES) <- c("Precisión","Boosts")

#############################
## CÁLCULO DEL RENDIMIENTO DEL MODELO CON MAYOR PRECISIÓN SEGÚN EL BOOST
#############################

#Creo modelo con el boost de mayor precisión (en este caso el de 7 boosts)
modelo_mejor_boost <- C5.0(pat_car_train[-14], pat_car_train$Heart.Disease,
                     trials = RES$Boosts[which.max(RES$Precisión)])

#Predicción del modelo creado en la iteración con los datos de testeo
prediccion_mejor_boost <- predict(modelo_mejor_boost, pat_car_test)

#Genero matriz de confusión del modelo con mayor precisión: 82%
confusionMatrix(prediccion_mejor_boost, pat_car_test$Heart.Disease)

library(gmodels)
CrossTable(pat_car_test$Heart.Disease, prediccion_mejor_boost,
           prop.chisq = FALSE, prop.c = FALSE, prop.r = FALSE,
           dnn = c('actual default', 'predicted default'))

#No tiene una precisión mayor que el generado con la función rpart


#############################
## (extra) OPTIMIZAR EL ÁRBOL DE DECISIÓN EN RELACIÓN CON EL COSTE COMPUTACIONAL
#############################

# Plotear valores de coste computacional del modelo con mayor precisión 
plotcp(mayor_precision)
 
# Plotear tabla de coste computacional
print(mayor_precision$cptable)


#Obtener el valor óptimo de coste computacional 
#En relación con el error de validación cruzada

index <- which.min(mayor_precision$cptable[, "xerror"])

cp_optimo <- mayor_precision$cptable[index, "CP"]

# Genero modelo con el coste computacional óptimo obtenido
 
mayor_precision_opt <- prune(tree = mayor_precision, cp = cp_optimo)

mayor_precision_opt$cptable
# Plotear y calcular precisión

rpart.plot(x = mayor_precision_opt, yesno = 2, type = 0, extra = 0)

pred_opt <- predict(object = mayor_precision_opt,
                  newdata = pat_car_test,
                  type = "class")
accuracy(actual = pat_car_test$Heart.Disease, 
         predicted = pred_opt) 

#Muestra una precisión muy buena, pero obviamente menor que el modelo no optimizado

