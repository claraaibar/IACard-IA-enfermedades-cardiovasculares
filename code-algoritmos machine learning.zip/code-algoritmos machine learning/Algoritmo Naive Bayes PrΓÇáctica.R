#Práctica 2 Minería de datos: Clara Aibar
####################################
#ALGORITMO SUPERVISADO: NAIVE BAYES
####################################

setwd("C:/Users/Usuario/Documents/directorio R")


#install.packages("naivebayes")
library(naivebayes)

#install.packages("dplyr")
library(dplyr)


#Todos muestran la misma precisión
modelo_bayes <- naive_bayes(Heart.Disease ~ ., data = pat_car_train, usekernel = T)

modelo_bayes2 <- naive_bayes(Heart.Disease ~ ., data = pat_car_train, usekernel = T, usepoisson = T) 

modelo_bayes3 <- naive_bayes(Heart.Disease ~ ., data = pat_car_train, usekernel = T, laplace = 5)


#Predecimos los datos del testeo con los modelos generados
pred_bayes <- predict(modelo_bayes, pat_car_test)

pred_bayes_2 <- predict(modelo_bayes2, pat_car_test)

pred_bayes_3 <- predict(modelo_bayes3, pat_car_test)


#Imprimimos su matriz de confusión: mismas características aun variando parámetros del modelo
matriz_confusion_bayes <- confusionMatrix(pat_car_test$Heart.Disease, pred_bayes, positive = "Presence");matriz_confusion_bayes

matriz_confusion_bayes_2 <- confusionMatrix(pat_car_test$Heart.Disease, pred_bayes_2, positive = "Presence");matriz_confusion_bayes_2

matriz_confusion_bayes_3 <- confusionMatrix(pat_car_test$Heart.Disease, pred_bayes_3, positive = "Presence");matriz_confusion_bayes_3

