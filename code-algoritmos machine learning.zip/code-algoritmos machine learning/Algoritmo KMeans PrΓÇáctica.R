#Práctica 2 Minería de datos: Clara Aibar
##################################
#ALGORITMO NO SUPERVISADO: K-MEANS
##################################

#install.packages("stats")
library(stats)
pat_car_kmeans <- read.csv("Heart_Disease_Prediction.csv.csv", stringsAsFactors = T)


set.seed(123)

#install.packages("factoextra")
library("factoextra")

#Bucle para generar algortimos con distintos números de clusters (24 modelos)

dispersion <- NULL
for (i in 2:25) {
  
  #Generamos modelos distintos en cada interación variando los grupos k
  res <- kmeans(scale(pat_car_kmeans[, -14]), i, nstart = 25)
  
  #Guardamos en una variable los valores de dispersión de los modelos
  dispersion <- c(dispersion,res$tot.withinss,i)
  
}

#Gaurdamos la dispersión intercluster, la cual es un indicar del rendimiento del algoritmo
dispersion <- as.data.frame(matrix(dispersion,ncol = 2,byrow = T))

#Guardamos el número de grupos de los modelos junto a su valor de dispersión 
colnames(dispersion) <- c("Varianza","Grupos")

#Ploteamos el data frame: gráfica para la técnica del codo
plot(x=dispersion$Grupos,y=dispersion$Varianza)

#Método del codo: calculamos las diferentes varianzas interclusters con diferentes números de grupos
#El valor en el que se estabilice la gráfica es el óptimo: aproximadamente cuando k = 6


res.km_opt <- kmeans(scale(pat_car_kmeans[, -14]), 6, nstart = 25)

fviz_cluster(res.km_opt, data = pat_car_kmeans[, -14],
             #palette = c("#2E9FDF", "#00AFBB", "#E7B800","#2E9FDF", "#00AFBB", "#E7B800","#2E9FDF", "#00AFBB"), 
             palette = c("#708090", "#7FFFD4", "#FFE1FF","#0000FF", "#FF4040", "#7FFF00"), 
             geom = "point",
             ellipse.type = "convex", 
             ggtheme = theme_bw()
)




#PROBAR CON DOS GRUPOS PARA VER LA PRECISIÓN DEL MODELO: COMO SI FUERA UNO SUPERVISADO

#Genero modelo con dos grupos
res.km_2 <- kmeans(scale(pat_car_kmeans[, -14]), 2, nstart = 25)
# K-means clusters showing the group of each individuals
res.km_2
a <- res.km_2$cluster
as.data.frame(a)
a<-cbind(a,pat_car_kmeans[14])


#Para saber a qué valores corresponden el 0 y el 1 (si a presence o a absence) 
#se calculan las veces que coinciden
#
length(which(a$a==1 & a$Heart.Disease=="Presence"))
#89! Seguramente el 2 sea asignado a Presence
length(which(a$a==2 & a$Heart.Disease=="Presence"))

#137, seguramente el 1sea asignado a Absence. Ambos datos coincides
length(which(a$a==1 & a$Heart.Disease=="Absence"))
length(which(a$a==2 & a$Heart.Disease=="Absence"))

#Determinamos que 2 es absence y 1 es presence, guardamos valores en una nueva columna
a[which(a$a==1),3]<- "Presence"
a[which(a$a==2),3]<- "Absence"
colnames(a)<- c("Clusters","Variable.a.predecir","Predicción")

#Esta nueva columna será equivalente a la predicción, por lo que la convertimos en factor
prediccion_kmeans <- as.factor(a$Predicción)

library(caret)
#Matriz de confusión para comparar con los datos del testeo
confusionMatrix(prediccion_kmeans, pat_car_kmeans$Heart.Disease, positive = "Presence")


#Ploteamos división en dos grupos
fviz_cluster(res.km_2, data = pat_car_kmeans[, -14],
             palette = c("#A020F0", "#BFEFFF"), 
             geom = "point",
             ellipse.type = "convex", 
             ggtheme = theme_bw()
)
