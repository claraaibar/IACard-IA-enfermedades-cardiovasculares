#Práctica 2 Minería de datos: Clara Aibar
#########################################
#ALGORITMO SUPERVISADO: REDES NEURONALES
#########################################

setwd("C:/Users/Usuario/Documents/directorio R")


#Librerías para generar el modelo

#install.packages("neuralnet")
library(neuralnet)

#install.packages("caret")
library(caret)

modelo_y_rendimiento <-c()

#Función para crear modelo de red neuronal con distintos números de capas ocultas
crear_modelo_y_rendimiento <-function(numero_hidden){
  
  set.seed(12345)
  
  nombre_modelo <- neuralnet (formula = Heart.Disease ~ Age + Sex +
                             Chest.pain.type + BP + Cholesterol  + 
                             FBS.over.120 + EKG.results + Max.HR  +
                             Exercise.angina + ST.depression + Slope.of.ST +
                             Number.of.vessels.fluro +Thallium,
                           data = pat_car_train, hidden = numero_hidden)
  
  #La predición que genera el modelo no es de una sola variable como por lo general
  #Te da la probabilidad de que sea Absence y Presence (en dos columnas)
  prediccion <- predict(nombre_modelo, pat_car_test)
  
  #Le ponemos etiquetas a las columnas de la predicón
  colnames(prediccion) <- c("Absence","Presence")
  
  #Son variables atómicas, hay que convertir a un data frame para poder acceder a sus datos
  prediccion_df <- as.data.frame(prediccion)
  
  #Añadimos etiqueta en una tercera columna
  #En función de las probabilidades de que sea "Presence" o "Absence"
  prediccion_df[which(prediccion_df$Presence<prediccion_df$Absence),3] <- "Absence"
  prediccion_df[which(prediccion_df$Presence>prediccion_df$Absence),3] <- "Presence"
  
  #Convertimos predicciones a factor
  prediccion_df$V3 <- as.factor(prediccion_df$V3)
  
  colnames(prediccion_df) <- c("Presence","Absence", "Predicción")
  
  #Matriz de confución con datos de predicción y testeo
  matrizConfusion_ANN <-confusionMatrix(prediccion_df$Predicción,pat_car_test$Heart.Disease)

  return(matrizConfusion_ANN)
  
}


#Creamos modelo de 2 capas de 50 redes y vemos su matriz de confusión
#Es el que más rendimiento ha demostrado
modelo_2capas_de50<- crear_modelo_y_rendimiento(c(50,50));modelo_2capas_de50



#PLOTEAR EL MODELO
modelo_2capas_de50 <- neuralnet (formula = Heart.Disease ~ Age + Sex +
                                   Chest.pain.type + BP + Cholesterol  + 
                                   FBS.over.120 + EKG.results + Max.HR  +
                                   Exercise.angina + ST.depression + Slope.of.ST +
                                   Number.of.vessels.fluro +Thallium,
                                 data = pat_car_train, hidden = c(50,50))

modelo <- modelo_2capas_de50

#install.packages("NeuralNetTools")
library(NeuralNetTools)

par(mar = numeric(4), family = 'serif')

#Tarda un buen rato
plotnet(modelo, alpha=0.6)


#Bucle para calcular precisión de las redes con distintos números de neuronas ocultas
#No he podido probarlo porque se queda cargando :)
# 
# modelos_redes <- list()
# 
# for( i in seq(from =1, to =60, by =5)){
#   
#   
#   modelos_redes[[i]]<- neuralnet (formula = Heart.Disease ~ Age + Sex +
#                                     Chest.pain.type + BP + Cholesterol  + 
#                                     FBS.over.120 + EKG.results + Max.HR  +
#                                     Exercise.angina + ST.depression + Slope.of.ST +
#                                     Number.of.vessels.fluro +Thallium,
#                                   data = pat_car_train, hidden = i)
#   
#   
#   
# }
# for (i in 1:modelos_redes) {
#   
#   # Valor para conocer el modelo que se analiza en la iteración
#   modelo <- modelos_redes[[i]]
#   
#   # Hago la predicción del modelo en los datos de testeo
#   pred <- predict(object = modelo,
#                   newdata = pat_car_test,
#                   type = "class")
#   
#   # Calculo la precisión de los datos generados por el modelo con los reales del test
#   #Almaceno su valor en la variable de precisiones
#   valores_precision_redes[i] <- accuracy(actual = pat_car_test$Heart.Disease, 
#                                          predicted = pred)
# }
#mayor_precision_redes <- modelos_redes[[which.max(valores_precision_redes)]]
